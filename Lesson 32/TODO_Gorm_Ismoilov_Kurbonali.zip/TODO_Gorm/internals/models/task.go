package models

import (
	"gorm.io/gorm"
	"time"
)

type Task struct {
	gorm.Model
	Title          string
	Description    string
	TaskPriorityID int `gorm:"-"`
	TaskPriority   string
	UserName       string
	IsDone         bool `gorm:"default:false"`
	DoneAt         time.Time
	IsDeleted      bool `gorm:"default:false"`
}

type TaskPriority struct {
	gorm.Model
	Priority string
}
