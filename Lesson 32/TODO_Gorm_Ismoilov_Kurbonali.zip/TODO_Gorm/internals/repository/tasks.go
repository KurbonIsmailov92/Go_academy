package repository

import (
	"todo-gorm/internals/db"
	"todo-gorm/internals/models"
)

func SetNewTaskToDB(t models.Task) error {
	err := db.GetDBConnection().Create(t).Error
	if err != nil {
		return err
	}
	return nil
}

func GetAllTasks() (tasks []models.Task, err error) {
	tasks = []models.Task{}
	err = db.GetDBConnection().Omit("id", "priority_id").Find(&tasks).Error
	if err != nil {
		return nil, err
	}
	return tasks, nil
}

func GetTaskByID(taskID int) (task models.Task, err error) {

	err = db.GetDBConnection().Raw(db.GetTasksByIDQuery, taskID).Scan(&task).Error
	if err != nil {
		return models.Task{}, err
	}

	return task, nil

}

func UpdateTaskTitleByID(taskID int, newTitle string) error {

	err := db.GetDBConnection().Raw(db.UpdateTaskTitleByIDQuery, newTitle, taskID).Error
	if err != nil {
		return err
	}
	return nil
}

func UpdateTaskUserByID(taskID int, newUsername string) error {
	err := db.GetDBConnection().Raw(db.UpdateTaskUserNameByIDQuery, newUsername, taskID).Error
	if err != nil {
		return err
	}
	return nil
}

func UpdateTaskPriorityByID(taskID int, newPrID int) error {
	err := db.GetDBConnection().Raw(db.UpdateTaskPriorityByIDQuery, newPrID, taskID).Error
	if err != nil {
		return err
	}
	return nil
}

func UpdateTaskDescriptionByID(taskID int, newDescription string) error {
	err := db.GetDBConnection().Raw(db.UpdateTaskDescriptionByIDQuery, newDescription, taskID).Error
	if err != nil {
		return err
	}
	return nil
}

func DoneTaskByID(taskID int) error {
	db.GetDBConnection().Table("tasks").Where("id = ?").Update("is_done", true)
	return nil

}

func UnDoneTaskByID(taskID int) error {
	db.GetDBConnection().Table("tasks").Where("id = ?").Update("is_done", false)
	return nil

}

func DeleteTaskByID(taskID int) error {
	db.GetDBConnection().Table("tasks").Where("id = ?").Update("is_deleted", true)
	return nil
}

func CancelTaskDeletionByID(taskID int) error {
	db.GetDBConnection().Table("tasks").Where("id = ?").Update("is_deleted", false)
	return nil

}

func GetDoneTasks() ([]models.Task, error) {
	var tasks []models.Task
	err := db.GetDBConnection().Raw(db.GetDoneTasksQuery).Scan(&tasks).Error
	if err != nil {
		return tasks, err
	}
	return tasks, nil
}

func GetDeletedTasks() ([]models.Task, error) {
	var tasks []models.Task
	err := db.GetDBConnection().Raw(db.GetDeletedTasksQuery).Scan(&tasks).Error
	if err != nil {
		return tasks, err
	}
	return tasks, nil
}
